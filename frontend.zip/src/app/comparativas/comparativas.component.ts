import { Component } from '@angular/core';

@Component({
  selector: 'app-comparativas',
  templateUrl: './comparativas.component.html',
  styleUrl: './comparativas.component.scss'
})
export class ComparativasComponent {

}
